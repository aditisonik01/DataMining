%loading the data and classes
train_data = importdata('X_train.mat');
class_train = importdata('y_train.mat');
test_data = importdata('X_test.mat');
class_test = importdata('y_test.mat');

[knn_class, knn_acc]=p2a(train_data, class_train, test_data, class_test);
[svm_class, svm_acc]=p2b(train_data, class_train, test_data, class_test);
[ann_class, ann_acc]=p2c(train_data, class_train, test_data, class_test);

disp('accuracy for KNN is: ');disp(knn_acc);
disp('accuracy for SVM is: ');disp(svm_acc);
disp('accuracy for ANN is: ');disp(ann_acc);

ann_class_correct=transpose(ann_class);

for i=1:3251
    class_compare(i,1)=knn_class(i);
    class_compare(i,2)=svm_class(i);
    class_compare(i,3)=ann_class_correct(i);
end

for j=1:3251
    m(j)=mode(class_compare(j,:));
end

majority_class=transpose(m);

count=0;
for l=1:3251
    count= count+(majority_class(l)==class_test(l));
end
accuracy=((count/3251)*100);

disp('Ensemble Accuracy is: ');disp(accuracy);