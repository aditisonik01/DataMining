function [class,accuracy] = p2a(train_data, class_train, test_data, class_test)

%classifies 7 nearest train_data and predicts the class of test_data
class=knnclassify(test_data,train_data,class_train,7);

%predicted class is validated with actual class to find the performance
cp=classperf(class_test,class);
accuracy=(cp.correctRate * 100);  %accuracy is got