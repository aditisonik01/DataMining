function [class,accuracy] = p2b(train_data, class_train, test_data, class_test)
class1 = unique(class_train);
train_labels = [];
test_data_labels = [];

%Polynomial kernel with degree 2
for x = 1:size(class1,1)
    Group = class_train;
    lID = Group(:,1) ~= class1(x);    
    Group(lID,1) = -1 ;
    train_labels = horzcat(train_labels,Group);
    Z = train_labels(:,x);
    SVMModel = fitcsvm(train_data,Z,'KernelFunction','polynomial','PolynomialOrder',2);
    L = predict(SVMModel,test_data);
    test_data_labels = horzcat(test_data_labels,L);
end
class = [];
total = 0;
for x = 1:size(test_data_labels,1)
    p = test_data_labels(x,:);
    class = vertcat(class,max(p));
    if (class(x) == class_test(x))
        total = total + 1;
    end
end
accuracy = (total/size(test_data_labels,1))*100;